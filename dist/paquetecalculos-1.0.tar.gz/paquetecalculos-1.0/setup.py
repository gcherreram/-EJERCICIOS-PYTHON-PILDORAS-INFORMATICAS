from setuptools import setup

setup(

    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Gabriel",
    author_email="gabo0423@hotmail.com",
    url="www........",
    packages=["calculos","calculos.redondeo_potencia"]

)